// Name:			Matheus Leitao	
// Student Number:	148 300 171
// Email:			mfleitao@myseneca.ca	
// Workshop:		Workshop #1: in_home

#ifndef NAMESPACE_SICT_TOOLS_H
#define NAMESPACE_SICT_TOOLS_H

namespace sictTools {

	// Displays the user interface menu
	int menu();

	// Performs a fool-proof integer entry
	int getInt(int, int);
}

#endif